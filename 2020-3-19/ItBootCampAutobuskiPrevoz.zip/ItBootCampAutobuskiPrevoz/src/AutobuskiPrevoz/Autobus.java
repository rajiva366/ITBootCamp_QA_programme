package AutobuskiPrevoz;

import java.util.ArrayList;

public class Autobus {

	/*
	 * Autobus poseduje naziv, vozaca, cenu karte i listu putnika koji se njime
	 * voze. Naziv i cena karte i zadaju se prilikom kreiranja. Moguce je
	 * dodati/ukloniti putnika kao i vozaca. Moguce je naplatiti kartu putnicima
	 * samo ako je vozac prisutan. Autobus ispisati u sledecem obliku: Naziv ( vozac
	 * - Putnik1[novac], Putnik2 [novac],... )
	 */

	private String naziv;
	private Vozac vozacAutobusa;
	private double cenaKarte;
	private ArrayList<Putnik> listaPutnika;

	public Autobus(String naziv, double cenaKarte) {
		super();
		this.naziv = naziv;
		this.cenaKarte = cenaKarte;
		listaPutnika = new ArrayList<Putnik>();
	}

	public boolean naplataKarte(Putnik p) {
		if (vozacAutobusa != null) {
			p.oduzmiNovac(cenaKarte);
			return true;
		} else {
			System.out.println("Ne moze se naplatiti karta, posto nema vozaca");
			return false;
		}
	}

	public void dodajPutnika(Putnik p) {
		if (naplataKarte(p))
			listaPutnika.add(p);
	}

	public void ukloniPutnika(Putnik p) {
		listaPutnika.remove(p);
	}

	public void dodajVozaca(Vozac v) {
		if (vozacAutobusa!=null) {
			System.out.println("Vozac autobusa vec postoji");
		} else
			vozacAutobusa = v;
	}

	public void ukloniVozaca(Vozac v) {
		if (vozacAutobusa ==v)
			vozacAutobusa = null;
	}

	public void prikaziPutnike() {
		for (int i = 0; i < listaPutnika.size(); i++) {
			if (i < listaPutnika.size() - 1) {
				System.out.print(listaPutnika.get(i) + " [" + listaPutnika.get(i).getNovac() + "], ");
			} else {
				System.out.print(listaPutnika.get(i) + " [" + listaPutnika.get(i).getNovac() + "]");
			}
		}
	}
	
	public void ispisiAutobus() {
		System.out.print(naziv+" ("+vozacAutobusa+" - ");
		prikaziPutnike();
	}

}
