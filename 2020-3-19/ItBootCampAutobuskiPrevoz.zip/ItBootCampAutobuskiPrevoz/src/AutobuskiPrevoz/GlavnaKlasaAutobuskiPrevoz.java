package AutobuskiPrevoz;

public class GlavnaKlasaAutobuskiPrevoz {

	public static void main(String[] args) {


		Putnik p1 = new Putnik("Mika", "Peric", 4000.00);
		Putnik p2 = new Putnik("Pera", "Mikic", 10000.00);
		Putnik p3 = new Putnik("Anta", "Rakic", 8000.00);
		
		System.out.println(p1);
		
		Vozac v1 = new Vozac("Miki", "Lozana", "Sofer autobusa");
		Vozac v2 = new Vozac("Dobrica", "Mikic", "Sofer autobusa");
		
		Autobus a1=new Autobus("Krstic i sinovi", 400.00);
		a1.dodajPutnika(p1);
		a1.ispisiAutobus();
		System.out.println(" ");
		
		a1.dodajVozaca(v1);
		a1.dodajPutnika(p1);
		a1.ispisiAutobus();
		System.out.println(" ");
		a1.dodajPutnika(p2);
		a1.ispisiAutobus();
		System.out.println(" ");
		a1.ukloniVozaca(v1);
		a1.ispisiAutobus();
		System.out.println(" ");
		a1.dodajPutnika(p3);
		a1.ispisiAutobus();
		System.out.println(" ");
		a1.dodajVozaca(v2);
		a1.dodajPutnika(p3);
		a1.ispisiAutobus();
		
		
		
	}

}
